CORRIGE DES EXERCICES MAT101
============================

Contenu
-------
- Corrige_MAT101.tex : fichier principal modulaire.
- chapitre1.tex à chapitre4.tex : solutions par chapitre.
- Corrige_exercices_MAT101_autonome.tex : version LaTeX en un seul fichier.

Compilation
-----------
Dans ce dossier, exécuter :

    latexmk -pdf Corrige_MAT101.tex

La version autonome se compile avec :

    latexmk -pdf Corrige_exercices_MAT101_autonome.tex

Une distribution LaTeX récente contenant les paquets usuels AMS, hyperref,
longtable, booktabs, enumitem, needspace, fancyhdr et microtype est requise.

Crédits et statut
-----------------
Les énoncés proviennent du polycopié collectif MAT101 de l'Université Grenoble
Alpes (édition du 13 septembre 2022). La rédaction initiale du corrigé a été
assistée par OpenAI ChatGPT. Édition, contrôle de structure et publication :
Kieran McShane, avec OpenAI Codex.

Ce corrigé est une ressource pédagogique non officielle. Sa couverture des
103 exercices et la correspondance des numéros ont été contrôlées ; le contenu
mathématique n'a pas encore fait l'objet d'une relecture humaine intégrale.
